
export async function analyzeAudio(file) {
  const AudioContextClass =
    window.AudioContext || window.webkitAudioContext

  if (!AudioContextClass) {
    throw new Error('Your browser does not support audio analysis.')
  }

  const audioContext = new AudioContextClass()

  try {
    const fileData = await file.arrayBuffer()
    const audioBuffer = await audioContext.decodeAudioData(fileData)

    const duration = audioBuffer.duration
    const sampleRate = audioBuffer.sampleRate
    const channelCount = audioBuffer.numberOfChannels

    // Combine the audio channels into one signal.
    const length = audioBuffer.length
    const samples = new Float32Array(length)

    for (let channel = 0; channel < channelCount; channel++) {
      const channelData = audioBuffer.getChannelData(channel)

      for (let i = 0; i < length; i++) {
        samples[i] += channelData[i] / channelCount
      }
    }

    // Measure overall loudness and peak amplitude.
    let sumSquares = 0
    let peak = 0
    let crossings = 0

    for (let i = 0; i < length; i++) {
      const value = samples[i]

      sumSquares += value * value
      peak = Math.max(peak, Math.abs(value))

      if (
        i > 0 &&
        ((samples[i - 1] < 0 && value >= 0) ||
          (samples[i - 1] >= 0 && value < 0))
      ) {
        crossings++
      }
    }

    const rms = Math.sqrt(sumSquares / Math.max(length, 1))
    const loudnessPercent = Math.round(rms * 1000) / 10
    const peakPercent = Math.round(peak * 1000) / 10

    // A rough estimate of tempo from changes in short-window energy.
    const windowSize = Math.max(1, Math.floor(sampleRate * 0.02))
    const energy = []

    for (let start = 0; start < length; start += windowSize) {
      const end = Math.min(start + windowSize, length)
      let windowSum = 0

      for (let i = start; i < end; i++) {
        windowSum += samples[i] * samples[i]
      }

      energy.push(Math.sqrt(windowSum / (end - start)))
    }

    const changes = energy.map((value, i) =>
      i === 0 ? 0 : Math.max(0, value - energy[i - 1])
    )

    const framesPerSecond = sampleRate / windowSize
    let bestBpm = null
    let bestScore = 0

    // Search plausible tempos from 60 to 180 BPM.
    for (let bpm = 60; bpm <= 180; bpm++) {
      const lag = Math.round((60 / bpm) * framesPerSecond)

      if (lag < 1 || lag >= changes.length) continue

      let score = 0

      for (let i = lag; i < changes.length; i++) {
        score += changes[i] * changes[i - lag]
      }

      if (score > bestScore) {
        bestScore = score
        bestBpm = bpm
      }
    }

    return {
      fileName: file.name,
      duration,
      sampleRate,
      channelCount,
      loudnessPercent,
      peakPercent,
      zeroCrossingRate: crossings / Math.max(length, 1),
      estimatedBpm: bestScore > 0 ? bestBpm : null,
    }
  } finally {
    await audioContext.close()
  }
}
