
import { useEffect, useRef, useState } from 'react'
import { analyzeAudio } from './audioAnalyzer'
import './App.css'
import { Client } from '@gradio/client'

const moods = [
  'Dreamy',
  'Emotional',
  'Peaceful',
  'Happy',
  'Mysterious',
  'Epic',
]

const instruments = [
  'Piano',
  'Guitar',
  'Flute',
  'Violin',
  'Music Box',
  'Synthesizer',
]

const GRADIO_URL = 'https://18e590b59c0b733c97.gradio.live'

function App() {
  const [file, setFile] = useState(null)
  const [audioUrl, setAudioUrl] = useState('')
  const [mood, setMood] = useState('Dreamy')
  const [instrument, setInstrument] = useState('Piano')
  const [mode, setMode] = useState('preserve')
  const [analysis, setAnalysis] = useState(null)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [changes, setChanges] = useState('')
  const [generatedAudioUrl, setGeneratedAudioUrl] = useState('')
  const fileInput = useRef(null)

  useEffect(() => {
    if (!file) {
      setAudioUrl('')
      return
    }

    const url = URL.createObjectURL(file)
    setAudioUrl(url)

    return () => URL.revokeObjectURL(url)
  }, [file])

  useEffect(() => {
    return () => {
      if (generatedAudioUrl) {
        URL.revokeObjectURL(generatedAudioUrl)
      }
    }
  }, [generatedAudioUrl])

  function handleFile(event) {
    const selected = event.target.files?.[0]
    if (!selected) return

    if (
      !selected.type.startsWith('audio/') &&
      !/\.(mp3|wav|m4a|ogg|flac|aac)$/i.test(selected.name)
    ) {
      setMessage('Please choose a supported audio file.')
      return
    }

    setFile(selected)
    setAnalysis(null)
    setMessage('')
  }

  async function handleAnalysis() {
    if (!file) {
      setMessage('Upload your tune first.')
      return
    }

    setBusy(true)
    setMessage('Analysing your audio in the browser…')

    try {
      const result = await analyzeAudio(file)
      setAnalysis(result)
      setMessage('Basic audio analysis complete.')
    } catch (error) {
      setMessage(
        error.message || 'Audio analysis failed. Try a WAV or MP3 file.'
      )
    } finally {
      setBusy(false)
    }
  }

  async function generateMusic() {
    setBusy(true)
    setMessage('Connecting to ReTune AI…')

    try {
      const client = await Client.connect(GRADIO_URL)

      const refinement = changes.trim()
        ? ` Additional instructions: ${changes.trim()}.`
        : ''

      const prompt = `Create a ${mood.toLowerCase()}, expressive ${instrument.toLowerCase()} instrumental melody.
${mode === 'preserve'
  ? 'Keep the musical idea simple and coherent.'
  : 'Create a fresh, creative musical variation.'}
${refinement}
No vocals. Make the ${instrument.toLowerCase()} the main instrument.`

      setMessage('Generating music… this may take a little while.')

      const result = await client.predict('/generate_music', {
        prompt,
      })

      console.log('MusicGen result:', result)

      const data = result?.data
      const audioOutput = Array.isArray(data) ? data[0] : null
      const audioPath =
        typeof audioOutput === 'string'
          ? audioOutput
          : audioOutput?.url || audioOutput?.path

      if (audioPath) {
        setGeneratedAudioUrl(audioPath)
        setMessage('Music generated! Your audio is ready below.')
      } else {
        setMessage(
          'Generation returned a result. Check the browser console (F12) for its audio details.'
        )
      }
    } catch (error) {
      console.error('Music generation failed:', error)
      setMessage(
        `Could not generate music: ${error?.message || 'Check that the Colab notebook is running and the Gradio link is active.'}`
      )
    } finally {
      setBusy(false)
    }
  }

  return (
    <main className="studio">
      <nav className="topbar">
        <a className="brand" href="#">
          ♫ <span>ReTune</span> <em>AI</em>
        </a>
        <span className="topbar-label">YOUR PERSONAL AI MUSIC STUDIO</span>
        <span className="live-status"><i /> Studio preview</span>
      </nav>

      <header className="hero">
        <p className="eyebrow">YOUR IDEA. YOUR SOUND.</p>
        <h1>
          Make your tune
          <br />
          <span>feel different.</span>
        </h1>
        <p className="hero-copy">
          Bring your own melody. Choose a mood, imagine a new instrument,
          and shape your music into something personal.
        </p>

        <div className="workflow">
          {['Upload', 'Analyse', 'Arrange', 'Refine'].map((step, index) => (
            <div className="workflow-step" key={step}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              {step}
            </div>
          ))}
        </div>
      </header>

      <section className="studio-layout">
        <div className="main-column">
          <section className="panel">
            <div className="section-title">
              <span className="step">01</span>
              <div>
                <h2>Bring your tune</h2>
                <p>Start with a beat, melody or recording.</p>
              </div>
            </div>

            <button
              className="upload-zone"
              onClick={() => fileInput.current?.click()}
            >
              <span className="upload-symbol">↑</span>
              <strong>
                {file ? file.name : 'Drop into your creative space'}
              </strong>
              <span>
                Click to browse · WAV, MP3, M4A and other supported formats
              </span>
              <b>{file ? 'Choose another file' : 'Choose audio file ↗'}</b>
            </button>

            <input
              ref={fileInput}
              type="file"
              accept="audio/*"
              hidden
              onChange={handleFile}
            />

            {file && audioUrl && (
              <div className="audio-card">
                <div className="audio-icon">♫</div>
                <div className="audio-info">
                  <strong>{file.name}</strong>
                  <span>{(file.size / (1024 * 1024)).toFixed(2)} MB</span>
                </div>
                <audio controls src={audioUrl} />
                <button
                  className="text-button"
                  onClick={() => {
                    setFile(null)
                    setAnalysis(null)
                    setMessage('')
                    if (fileInput.current) fileInput.current.value = ''
                  }}
                >
                  Remove
                </button>
              </div>
            )}
          </section>

          <section className="panel">
            <div className="section-title">
              <span className="step">02</span>
              <div>
                <h2>Understand your sound</h2>
                <p>Measure your audio before arranging it.</p>
              </div>
            </div>

            <button
              className="secondary-button"
              disabled={!file || busy}
              onClick={handleAnalysis}
            >
              {busy ? 'Working…' : '⌁ Analyse my audio'}
            </button>

            {analysis && (
              <div className="analysis-grid">
                <div>
                  <span>DURATION</span>
                  <strong>{analysis.duration.toFixed(1)} sec</strong>
                </div>
                <div>
                  <span>TEMPO ESTIMATE</span>
                  <strong>
                    {analysis.estimatedBpm
                      ? `${analysis.estimatedBpm} BPM`
                      : 'Unavailable'}
                  </strong>
                </div>
                <div>
                  <span>PEAK LEVEL</span>
                  <strong>{analysis.peakPercent}%</strong>
                </div>
                <div>
                  <span>SAMPLE RATE</span>
                  <strong>{(analysis.sampleRate / 1000).toFixed(1)} kHz</strong>
                </div>
              </div>
            )}

            <p className="hint">
              Tempo is an estimate. Accurate note extraction and key detection
              are planned for the next stage.
            </p>
          </section>

          <section className="panel">
            <div className="section-title">
              <span className="step">03</span>
              <div>
                <h2>Choose your direction</h2>
                <p>How much should your original melody change?</p>
              </div>
            </div>

            <div className="mode-grid">
              <button
                className={`mode-card ${mode === 'preserve' ? 'selected' : ''}`}
                onClick={() => setMode('preserve')}
              >
                <span className="mode-emoji">♫</span>
                <strong>Preserve my melody</strong>
                <span>Keep the tune as recognizable as possible.</span>
              </button>

              <button
                className={`mode-card ${mode === 'variation' ? 'selected' : ''}`}
                onClick={() => setMode('variation')}
              >
                <span className="mode-emoji">✳</span>
                <strong>Create a variation</strong>
                <span>Use my tune as inspiration for a new arrangement.</span>
              </button>
            </div>

            <h3 className="subheading">What should it feel like?</h3>
            <div className="choice-grid">
              {moods.map(item => (
                <button
                  key={item}
                  className={`choice-chip ${mood === item ? 'active' : ''}`}
                  onClick={() => setMood(item)}
                >
                  {item}
                </button>
              ))}
            </div>

            <h3 className="subheading">Which instrument do you imagine?</h3>
            <div className="instrument-grid">
              {instruments.map((item, index) => (
                <button
                  key={item}
                  className={`instrument-card ${instrument === item ? 'active' : ''}`}
                  onClick={() => setInstrument(item)}
                >
                  <span>{['♬', '♩', '♯', '𝄞', '♫', '∿'][index]}</span>
                  <strong>{item}</strong>
                  {instrument === item && <b>✓</b>}
                </button>
              ))}
            </div>
          </section>

          <section className="panel refine-panel">
            <div className="section-title">
              <span className="step">04</span>
              <div>
                <h2>Refine your creation</h2>
                <p>Describe what you want to change after listening.</p>
              </div>
            </div>

            <textarea
              value={changes}
              onChange={event => setChanges(event.target.value)}
              placeholder="For example: make it slower, add a sad feeling, keep my original melody…"
              rows={3}
            />
            <p className="hint">
              Your refinement instructions are included in the text prompt sent
              to MusicGen.
            </p>
          </section>
        </div>

        <aside className="side-column">
          <section className="summary-card">
            <p className="eyebrow">YOUR SOUND BLUEPRINT</p>

            <div className="summary-row">
              <span>Source</span>
              <strong>{file ? 'Audio uploaded' : 'Text prompt'}</strong>
            </div>
            <div className="summary-row">
              <span>Arrangement</span>
              <strong>
                {mode === 'preserve' ? 'Preserve melody' : 'New variation'}
              </strong>
            </div>
            <div className="summary-row">
              <span>Mood</span>
              <strong>{mood}</strong>
            </div>
            <div className="summary-row">
              <span>Instrument</span>
              <strong>{instrument}</strong>
            </div>
            <div className="summary-row">
              <span>Analysis</span>
              <strong>{analysis ? 'Complete' : 'Not analysed'}</strong>
            </div>

            <button
              className="generate-button"
              onClick={generateMusic}
              disabled={busy}
            >
              {busy ? 'Generating…' : '✳ Generate my music ↗'}
            </button>

            {message && (
              <p className="status-message" role="status">
                {message}
              </p>
            )}

            {generatedAudioUrl && (
              <div className="generated-audio">
                <h3>Your generated music</h3>
                <audio controls src={generatedAudioUrl} />
                <a href={generatedAudioUrl} target="_blank" rel="noreferrer">
                  Open generated audio
                </a>
              </div>
            )}

            <p className="engine-note">
              <span>●</span> MusicGen connection · Colab
            </p>
          </section>

          <section className="tip-card">
            <span>✦ A SMALL TIP</span>
            <p>
              A clean recording of one melody is usually easier to analyse than
              a full song with vocals and drums.
            </p>
          </section>
        </aside>
      </section>

      <footer className="footer">
        <a className="brand" href="#">
          ♫ <span>ReTune</span> <em>AI</em>
        </a>
        <span>Made for the music in your imagination.</span>
      </footer>
    </main>
  )
}

export default App
